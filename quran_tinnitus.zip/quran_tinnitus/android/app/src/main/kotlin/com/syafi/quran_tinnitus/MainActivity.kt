package com.syafi.quran_tinnitus

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
